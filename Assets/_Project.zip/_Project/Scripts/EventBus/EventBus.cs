using _Project.Scripts.Components;
using _Project.Scripts.Events;

namespace _Project.Scripts
{
    public sealed class EventBus
    {
        public readonly EventChannel<EntityCreatedEvent> EntityCreated = new();
        public readonly EventChannel<EntityDestroyedEvent> EntityDestroyed = new();
        public readonly EventChannel<PositionChangedEvent> PositionChanged = new();
        public readonly EventChannel<SpawnRequest<PlayerTag>> PlayerSpawnRequests = new();
        public readonly EventChannel<SpawnRequest<EnemyTag>> EnemySpawnRequests = new();
        public readonly EventChannel<SpawnRequest<EnemySpawnerTag>> EnemySpawnerRequests = new();
        public readonly EventChannel<SpawnRequest<CoinTag>> CoinSpawnRequests = new();
        public readonly EventChannel<SpawnRequest<ProjectileTag>> ProjectileSpawnRequests = new();

        public void Clear()
        {
            EntityCreated.Clear();
            EntityDestroyed.Clear();
            PositionChanged.Clear();
            PlayerSpawnRequests.Clear();
            EnemySpawnRequests.Clear();
            EnemySpawnerRequests.Clear();
            CoinSpawnRequests.Clear();
            ProjectileSpawnRequests.Clear();
        }
    }
}