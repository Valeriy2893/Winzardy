namespace _Project.Scripts.Unity
{
    public interface IInputSource<out T> where T : struct
    {
        public T Read();
    }
}