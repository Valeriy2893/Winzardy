using _Project.Scripts.ECS.Components;
using UnityEngine;
using UnityEngine.InputSystem;

namespace _Project.Scripts.Input.Unity
{
    public sealed class KeyboardInputAdapter : MonoBehaviour
    {
        /// <summary>
        /// Последнее состояние ввода.
        /// ECS читает это значение.
        /// </summary>
        public InputData Current { get; private set; }

        private InputAction _move;

        private void Awake()
        {
            // Action без InputActionAsset (минимализм)
            _move = new InputAction(
                name: "Move",
                type: InputActionType.Value,
                expectedControlType: "Vector2"
            );

            // WASD
            _move.AddCompositeBinding("2DVector")
                .With("Up", "<Keyboard>/w")
                .With("Down", "<Keyboard>/s")
                .With("Left", "<Keyboard>/a")
                .With("Right", "<Keyboard>/d");

            // 🔥 Событийная подписка
            _move.performed += OnMove;
            _move.canceled += OnMove;
        }

        private void OnEnable()
        {
            _move.Enable();
        }

        private void OnDisable()
        {
            _move.Disable();
        }

        private void OnDestroy()
        {
            // обязательная очистка
            _move.performed -= OnMove;
            _move.canceled -= OnMove;
        }

        private void OnMove(InputAction.CallbackContext ctx)
        {
            Vector2 value = ctx.ReadValue<Vector2>();

            Current = new InputData
            {
                X = value.x,
                Z = value.y
            };
        }
    }
}