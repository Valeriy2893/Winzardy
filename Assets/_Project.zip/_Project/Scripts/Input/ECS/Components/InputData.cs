namespace _Project.Scripts.ECS.Components
{
    public struct InputData
    {
        public float X;
        public float Z;
    }
}