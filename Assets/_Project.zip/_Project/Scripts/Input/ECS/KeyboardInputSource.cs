using _Project.Scripts.ECS.Components;
using _Project.Scripts.Input.Unity;
using _Project.Scripts.Unity;

namespace _Project.Scripts.Input.ECS
{
    public readonly struct KeyboardInputSource : IInputSource<InputData>
    {
        private readonly KeyboardInputAdapter _adapter;

        public KeyboardInputSource(KeyboardInputAdapter adapter)
        {
            _adapter = adapter;
        }

        public InputData Read()
        {
            return _adapter.Current;
        }
    }
}