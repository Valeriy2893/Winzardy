namespace _Project.Scripts.Events
{
    public readonly struct SpawnEvent<TTag> where TTag : struct
    {
        public readonly float X;
        public readonly float Z;

        public SpawnEvent(float x, float z)
        {
            X = x;
            Z = z;
        }
    }
}