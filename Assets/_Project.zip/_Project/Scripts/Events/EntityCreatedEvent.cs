using _Project.Scripts.Entity;

namespace _Project.Scripts.Events
{
    public readonly struct EntityCreatedEvent
    {
        public readonly EntityId Entity;

        public EntityCreatedEvent(EntityId entity)
        {
            Entity = entity;
        }
    }
}