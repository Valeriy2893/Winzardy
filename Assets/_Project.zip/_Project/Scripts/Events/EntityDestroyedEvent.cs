using _Project.Scripts.Entity;

namespace _Project.Scripts.Components
{
    public readonly struct EntityDestroyedEvent
    {
        public readonly EntityId Entity;

        public EntityDestroyedEvent(EntityId entity)
        {
            Entity = entity;
        }
    }
}