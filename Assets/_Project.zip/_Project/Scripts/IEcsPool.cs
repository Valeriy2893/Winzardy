using System;
using _Project.Scripts.Entity;

namespace _Project.Scripts
{
    public interface IEcsPool
    {
        string Name { get; }
        Type ComponentType { get; }

        bool Has(EntityId entity);

#if UNITY_EDITOR
        void DrawDebug(EntityId entity);
#endif
    }
}