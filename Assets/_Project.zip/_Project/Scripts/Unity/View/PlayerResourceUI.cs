using TMPro;
using UnityEngine;
using _Project.Scripts.Components;

namespace _Project.Scripts.UI
{
    public sealed class PlayerResourceUI : MonoBehaviour
    {
        [SerializeField] private TMP_Text _text;

        private World _world;
        private EcsFilter<PlayerTag, Resource> _players;

        public void Init(World world)
        {
            _world = world;
            _players = world.GetFilter<PlayerTag, Resource>();
        }

        private void Update()
        {
            if (_players.Entities.Count == 0)
                return;

            var player = _players.Entities[0];
            ref var resource = ref _world.GetPool<Resource>().Get(player);

            _text.text = $"{resource.Value}";
        }
    }
}