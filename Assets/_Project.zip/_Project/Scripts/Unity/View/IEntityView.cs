using _Project.Scripts.Entity;

namespace _Project.Scripts.Unity.View
{
    public interface IEntityView
    {
        public void Init(World world, EntityId entityId);
    }
}