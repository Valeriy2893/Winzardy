using TMPro;
using UnityEngine;
using _Project.Scripts.Components;

namespace _Project.Scripts.UI
{
    public sealed class PlayerHealthUI : MonoBehaviour
    {
        [SerializeField] private TMP_Text _text;

        private World _world;
        private EcsFilter<PlayerTag, Health> _players;

        public void Init(World world)
        {
            _world = world;
            _players = world.GetFilter<PlayerTag, Health>();
        }

        private void Update()
        {
            if (_players.Entities.Count == 0)
                return;

            var player = _players.Entities[0];
            ref var health = ref _world.GetPool<Health>().Get(player);

            _text.text = $"{(int)health.Current}";
        }
    }
}