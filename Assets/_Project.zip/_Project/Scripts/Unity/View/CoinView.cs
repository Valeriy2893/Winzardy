using UnityEngine;
using EntityId = _Project.Scripts.Entity.EntityId;

namespace _Project.Scripts.Unity.View
{
    public sealed class CoinView : MonoBehaviour, IEntityView
    {
        public void Init(World world, EntityId entityId)
        {
            
        }
    }
}