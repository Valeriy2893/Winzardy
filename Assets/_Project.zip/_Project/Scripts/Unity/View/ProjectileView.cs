using UnityEngine;
using EntityId = _Project.Scripts.Entity.EntityId;

namespace _Project.Scripts.Unity.View
{
    public class ProjectileView: MonoBehaviour, IEntityView
    {
        public void Init(World world, EntityId entityId)
        {
            
        }
    }
}