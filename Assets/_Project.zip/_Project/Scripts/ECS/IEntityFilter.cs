using System.Collections.Generic;
using _Project.Scripts.Entity;

namespace _Project.Scripts
{
    public interface IEcsFilter
    {
        public IReadOnlyList<EntityId> Entities { get; }
        public void OnEntityChanged(EntityId entity);
        public void Clear();
    }
}