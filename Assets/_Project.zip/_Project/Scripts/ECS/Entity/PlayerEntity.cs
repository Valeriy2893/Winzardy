using _Project.Scripts.Entity;

namespace _Project.Scripts.ECS.Entity
{
    public struct PlayerEntity
    {
        public EntityId EntityId;
    }
}