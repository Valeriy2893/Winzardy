using System;
using System.Collections.Generic;
using _Project.Scripts.Components;
using _Project.Scripts.Components.Shared;
using _Project.Scripts.ECS.Entity;
using _Project.Scripts.Entity;

namespace _Project.Scripts
{
    public sealed class World : IDisposable
    {
        // =========================
        // ENTITY LIFECYCLE
        // =========================

        private int _nextEntityId;
        private readonly EntitySet _aliveEntities = new();
        public EntityId CreateEntity()
        {
            var id = new EntityId(_nextEntityId++);
            _aliveEntities.Add(id);
            return id;
        }

        public void DestroyEntity(EntityId entity)
        {
            if (!_aliveEntities.Contains(entity))
                return;

            EventBus.EntityDestroyed.Raise(new EntityDestroyedEvent(entity));
            RemoveAllComponents(entity);
            _aliveEntities.Remove(entity);
        }

        public bool IsAlive(EntityId entity)
        {
            return _aliveEntities.Contains(entity);
        }

        // =========================
        // COMPONENTS
        // =========================

        private readonly ComponentTypeRegistry _componentTypes = new();
        private IComponentPool[] _pools = new IComponentPool[32];

        public ComponentPool<T> GetPool<T>() where T : struct
        {
            int typeId = _componentTypes.GetId<T>();

            if (typeId >= _pools.Length)
                Array.Resize(ref _pools, Math.Max(_pools.Length * 2, typeId + 1));

            _pools[typeId] ??= new ComponentPool<T>(this);
            return (ComponentPool<T>)_pools[typeId];
        }

        private void RemoveAllComponents(EntityId entity)
        {
            for (int i = 0; i < _pools.Length; i++)
                _pools[i]?.Remove(entity);
        }

        // =========================
        // FILTERS
        // =========================

        private readonly List<IEcsFilter> _filters = new();

        public EcsFilter<T1> GetFilter<T1>() where T1 : struct
        {
            var filter = new EcsFilter<T1>(this);
            _filters.Add(filter);
            InitFilter(filter);
            return filter;
        }

        public EcsFilter<T1, T2> GetFilter<T1, T2>()
            where T1 : struct
            where T2 : struct
        {
            var filter = new EcsFilter<T1, T2>(this);
            _filters.Add(filter);
            InitFilter(filter);
            return filter;
        }

        public EcsFilter<T1, T2, T3> GetFilter<T1, T2, T3>()
            where T1 : struct
            where T2 : struct
            where T3 : struct
        {
            var filter = new EcsFilter<T1, T2, T3>(this);
            _filters.Add(filter);
            InitFilter(filter);
            return filter;
        }

        public EcsFilter<T1, T2, T3, T4> GetFilter<T1, T2, T3, T4>()
            where T1 : struct
            where T2 : struct
            where T3 : struct
            where T4 : struct
        {
            var filter = new EcsFilter<T1, T2, T3, T4>(this);
            _filters.Add(filter);
            InitFilter(filter);
            return filter;
        }

        private void InitFilter(IEcsFilter filter)
        {
            foreach (var entity in _aliveEntities.Entities)
                filter.OnEntityChanged(entity);
        }

        public void OnComponentChanged(EntityId entity)
        {
            for (int i = 0; i < _filters.Count; i++)
                _filters[i].OnEntityChanged(entity);
        }

        // =========================
        // EVENTS
        // =========================

        public readonly EventBus EventBus = new();

        // =========================
        // DEBUG / EDITOR
        // =========================

#if UNITY_EDITOR
        public ReadOnlySpan<EntityId> DebugAliveEntities => _aliveEntities.Entities;

        public IEnumerable<IComponentPool> DebugComponentPools
        {
            get
            {
                for (int i = 0; i < _pools.Length; i++)
                    if (_pools[i] != null)
                        yield return _pools[i];
            }
        }
#endif


        // =========================
        // DISPOSE
        // =========================

        public void Dispose()
        {
            EventBus.Clear();

            foreach (var filter in _filters)
                filter.Clear();

            _filters.Clear();

            for (int i = 0; i < _pools.Length; i++)
                _pools[i]?.Clear();

            Array.Clear(_pools, 0, _pools.Length);
            _componentTypes.Clear();

            _aliveEntities.Clear();
            _nextEntityId = 0;
        }
    }
}
