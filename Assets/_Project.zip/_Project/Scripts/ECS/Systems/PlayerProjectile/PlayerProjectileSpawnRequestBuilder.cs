using _Project.Scripts.Components;
using _Project.Scripts.ECS.Systems.Enemy;
using _Project.Scripts.Events;

namespace _Project.Scripts.ECS.Systems.PlayerProjectile
{
    public readonly struct PlayerProjectileSpawnRequestBuilder : ISpawnRequestBuilder<ProjectileTag>
    {
        private readonly EcsFilter<PlayerTag, Position> _players;

        public PlayerProjectileSpawnRequestBuilder(EcsFilter<PlayerTag, Position> players)
        {
            _players = players;
        }

        public SpawnRequest<ProjectileTag> Build(World world)
        {
            if (_players.Entities.Count == 0)
                return default;

            var player = _players.Entities[0];
            ref var pos = ref world.GetPool<Position>().Get(player);
            return new SpawnRequest<ProjectileTag>(pos.X, pos.Z, player);
        }
    }
}