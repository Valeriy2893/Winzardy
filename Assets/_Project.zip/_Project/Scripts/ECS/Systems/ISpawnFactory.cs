using _Project.Scripts.Events;

namespace _Project.Scripts.ECS.Systems.Spawners
{
    public interface ISpawnFactory<TTag> where TTag : struct
    {
        public void Create(World world, in SpawnRequest<TTag> request);
    }
}