using _Project.Scripts.Components;
using _Project.Scripts.Configs;
using _Project.Scripts.ECS.Systems.Enemy;
using _Project.Scripts.Entity;
using _Project.Scripts.Events;

namespace _Project.Scripts.ECS.Systems.Player
{
    public readonly struct PlayerSpawnRequestBuilder : ISpawnRequestBuilder<PlayerTag>
    {
        private readonly PlayerConfig _config;

        public PlayerSpawnRequestBuilder(PlayerConfig config)
        {
            _config = config;
        }

        public SpawnRequest<PlayerTag> Build(World world)
        {
            return new SpawnRequest<PlayerTag>(0, 0, new EntityId());
        }
    }
}