namespace _Project.Scripts.Systems
{
    public interface ISystem
    {
        void Update(World world, float deltaTime);
    }
}