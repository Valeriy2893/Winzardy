using _Project.Scripts.Events;

namespace _Project.Scripts.ECS.Systems.Enemy
{
    public interface ISpawnRequestBuilder<TTag> where TTag : struct
    {
        public SpawnRequest<TTag> Build(World world);
    }
}