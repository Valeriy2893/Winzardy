namespace _Project.Scripts.Components
{
    public struct ViewportBounds
    {
        public float MinX;
        public float MaxX;
        public float MinZ;
        public float MaxZ;
    }
}