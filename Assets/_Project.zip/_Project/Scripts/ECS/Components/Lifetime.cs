namespace _Project.Scripts.Components
{
    public struct Lifetime
    {
        public float TimeLeft;
    }
}