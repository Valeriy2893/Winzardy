namespace _Project.Scripts.Components
{
    public struct CollisionRadius
    {
        public float Value;
    }
}