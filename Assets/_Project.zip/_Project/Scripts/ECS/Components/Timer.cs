namespace _Project.Scripts.Components
{
    public struct Timer
    {
        public float TimeLeft;
        public float Interval;
    }
}