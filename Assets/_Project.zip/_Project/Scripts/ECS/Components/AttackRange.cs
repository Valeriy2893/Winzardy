namespace _Project.Scripts.Components
{
    public struct AttackRange
    {
        public float Value;
    }
}