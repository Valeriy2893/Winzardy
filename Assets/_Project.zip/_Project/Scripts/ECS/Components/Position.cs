namespace _Project.Scripts.Components
{
    public struct Position
    {
        public float X;
        public float Z;
    }
}