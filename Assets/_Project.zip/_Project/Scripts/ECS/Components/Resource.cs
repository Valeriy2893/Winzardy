namespace _Project.Scripts.Components
{
    public struct Resource
    {
        public int Value;
    }
}