namespace _Project.Scripts.Components
{
    public struct Health
    {
        public float  Current;
        public float  Max;
    }
}