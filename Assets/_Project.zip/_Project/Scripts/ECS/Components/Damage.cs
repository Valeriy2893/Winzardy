namespace _Project.Scripts.Components
{
    public struct Damage
    {
        public float Value;
    }
}