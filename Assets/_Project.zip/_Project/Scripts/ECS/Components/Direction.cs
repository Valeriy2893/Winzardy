namespace _Project.Scripts.Components
{
    public struct Direction
    {
        public float X;
        public float Z;
    }
}