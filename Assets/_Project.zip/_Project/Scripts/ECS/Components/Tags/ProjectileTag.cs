namespace _Project.Scripts.Components
{
    public struct ProjectileTag { }
}