namespace _Project.Scripts.Components
{
    public struct Velocity
    {
        public float X;
        public float Z;
        public float Speed;
    }
}