namespace _Project.Scripts.Components
{
    public struct DamageOverTime
    {
        public float DamagePerSecond;
    }
}