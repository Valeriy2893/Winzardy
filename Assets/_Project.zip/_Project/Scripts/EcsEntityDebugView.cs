using _Project.Scripts;
using UnityEngine;
using _Project.Scripts.Components;
using EntityId = _Project.Scripts.Entity.EntityId;

public sealed class EcsEntityDebugView : MonoBehaviour
{
    public World World;
    public EntityId Entity;

    private void OnDrawGizmos()
    {
        if (World == null)
            return;

        DrawPosition();
        DrawDirection();
        DrawCollision();
        DrawAttackRange();
    }

    private void DrawPosition()
    {
        if (!World.GetPool<Position>().Has(Entity))
            return;

        var pos = World.GetPool<Position>().Get(Entity);
        Gizmos.color = Color.red;
        Gizmos.DrawSphere(new Vector3(pos.X, 0, pos.Z), 0.12f);
    }

    private void DrawDirection()
    {
        if (!World.GetPool<Position>().Has(Entity))
            return;
        if (!World.GetPool<Direction>().Has(Entity))
            return;

        var pos = World.GetPool<Position>().Get(Entity);
        var dir = World.GetPool<Direction>().Get(Entity);

        Gizmos.color = Color.green;
        Gizmos.DrawLine(
            new Vector3(pos.X, 0, pos.Z),
            new Vector3(pos.X + dir.X, 0, pos.Z + dir.Z)
        );
    }

    private void DrawCollision()
    {
        if (!World.GetPool<Position>().Has(Entity))
            return;
        if (!World.GetPool<CollisionRadius>().Has(Entity))
            return;

        var pos = World.GetPool<Position>().Get(Entity);
        var r = World.GetPool<CollisionRadius>().Get(Entity);

        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(
            new Vector3(pos.X, 0, pos.Z),
            r.Value
        );
    }

    private void DrawAttackRange()
    {
        if (!World.GetPool<Position>().Has(Entity))
            return;
        if (!World.GetPool<AttackRange>().Has(Entity))
            return;

        var pos = World.GetPool<Position>().Get(Entity);
        var r = World.GetPool<AttackRange>().Get(Entity);

        Gizmos.color = Color.magenta;
        Gizmos.DrawWireSphere(
            new Vector3(pos.X, 0, pos.Z),
            r.Value
        );
    }
}
