using _Project.Scripts.Components;
using _Project.Scripts.Entity;

namespace _Project.Scripts.Condition.Conditions
{
    public readonly struct LifetimeExpiredCondition : IEntityCondition
    {
        public bool IsMet(World world, float dt, EntityId entity)
        {
            ref var lifetime = ref world.GetPool<Lifetime>().Get(entity);

            lifetime.TimeLeft -= dt;
            return lifetime.TimeLeft <= 0f;
        }
    }
}