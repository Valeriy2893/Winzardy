using _Project.Scripts.Components;

namespace _Project.Scripts.Condition
{
    public readonly struct ViewportCondition
    {
        private readonly EcsFilter<ViewportBounds> _viewports;

        public ViewportCondition(EcsFilter<ViewportBounds> viewports)
        {
            _viewports = viewports;
        }

        public bool IsMet()
        {
            return _viewports.Entities.Count > 0;
        }
    }
}