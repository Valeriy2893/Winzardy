using _Project.Scripts.Components;
using _Project.Scripts.ECS.Systems;
using _Project.Scripts.Systems;

namespace _Project.Scripts.Condition.ConditionSystems
{
    public sealed class MovementConditionSystem<TTag, TActions, TConditions> : ISystem
        where TTag : struct
        where TActions : struct, IAction
        where TConditions : struct, IEntityCondition
    {
        private TConditions _conditions;
        private TActions _actions;
        private readonly EcsFilter<TTag, Position, Velocity, Direction> _filter;

        public MovementConditionSystem(TActions actions, TConditions conditions,
            EcsFilter<TTag, Position, Velocity, Direction> filter)
        {
            _actions = actions;
            _conditions = conditions;
            _filter = filter;
        }

        public void Update(World world, float dt)
        {
            if (_filter.Entities.Count == 0)
                return;

            for (int i = 0; i < _filter.Entities.Count; i++)
            {
                if (!_conditions.IsMet(world, dt, _filter.Entities[i]))
                    continue;

                _actions.Execute(world, _filter.Entities[i], dt);
            }
        }
    }
}