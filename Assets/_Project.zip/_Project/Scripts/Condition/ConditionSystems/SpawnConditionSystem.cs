using _Project.Scripts.Condition;
using _Project.Scripts.Events;
using _Project.Scripts.Systems;
using UnityEngine;

namespace _Project.Scripts.ECS.Systems.Enemy
{
    public sealed class SpawnConditionSystem<TTag, TConditions, TBuilder> : ISystem
        where TTag : struct
        where TConditions : struct, IWorldCondition
        where TBuilder : struct, ISpawnRequestBuilder<TTag>
    {
        private readonly EventChannel<SpawnRequest<TTag>> _requests;
        private TConditions _conditions;
        private TBuilder _builder;

        public SpawnConditionSystem(EventChannel<SpawnRequest<TTag>> requests, TConditions conditions, TBuilder builder)
        {
            _requests = requests;
            _conditions = conditions;
            _builder = builder;
        }

        public void Update(World world, float dt)
        { 
            if (!_conditions.IsMet(world, dt))
                return;
            
            _requests.Raise(_builder.Build(world));
        }
    }
}