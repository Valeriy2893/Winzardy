using _Project.Scripts.Components;
using _Project.Scripts.Entity;

namespace _Project.Scripts.Condition.Conditions
{
    public readonly struct DeathCondition : IEntityCondition
    {
        public bool IsMet(World world, float dt, EntityId entity)
        {
            ref var hp = ref world.GetPool<Health>().Get(entity);
            return hp.Current <= 0;
        }
    }
}