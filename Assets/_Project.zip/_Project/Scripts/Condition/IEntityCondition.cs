using _Project.Scripts.Entity;

namespace _Project.Scripts.Condition
{
    public interface IEntityCondition
    {
        public bool IsMet(World world, float dt, EntityId entity);
    }
}