using _Project.Scripts.Components;
using _Project.Scripts.Condition;
using _Project.Scripts.Entity;

namespace _Project.Scripts.ECS.Systems.Player
{
    public readonly struct PlayerSpawnConditions : IWorldCondition
    {
        private readonly LimitCondition<PlayerTag> _limit;

        public PlayerSpawnConditions(LimitCondition<PlayerTag> limit)
        {
            _limit = limit;
        }

        public bool IsMet(World world, float dt)
        {
            return _limit.IsMet();
        }
    }
}