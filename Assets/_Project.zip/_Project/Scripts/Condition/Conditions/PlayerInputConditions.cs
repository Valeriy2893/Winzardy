using _Project.Scripts.Condition;
using _Project.Scripts.Entity;

namespace _Project.Scripts.Input
{
    public readonly struct PlayerInputConditions : IEntityCondition
    {
        private readonly AliveCondition _alive;

        public PlayerInputConditions(AliveCondition alive)
        {
            _alive = alive;
        }

        public bool IsMet(World world, float dt, EntityId entityId)
        {
            if (!_alive.IsMet(world, entityId))
                return false;

            return true;
        }
    }
}