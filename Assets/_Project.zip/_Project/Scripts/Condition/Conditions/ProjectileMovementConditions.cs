using _Project.Scripts.Entity;

namespace _Project.Scripts.Condition.Conditions
{
    public readonly struct ProjectileMovementConditions : IEntityCondition
    {
        private readonly DirectionCondition _direction;

        public ProjectileMovementConditions(DirectionCondition direction)
        {
            _direction = direction;
        }

        public bool IsMet(World world, float dt, EntityId entityId)
        {
            if (!_direction.IsMet(world, entityId))
                return false;

            return true;
        }
    }
}