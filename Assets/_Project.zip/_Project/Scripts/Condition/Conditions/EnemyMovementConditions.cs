using _Project.Scripts.Entity;

namespace _Project.Scripts.Condition.Conditions
{
    public readonly struct EnemyMovementConditions : IEntityCondition
    {
        private readonly AliveCondition _alive;
        private readonly DirectionCondition _direction;

        public EnemyMovementConditions(AliveCondition alive, DirectionCondition direction)
        {
            _alive = alive;
            _direction = direction;
        }

        public bool IsMet(World world, float dt, EntityId entityId)
        {
            if (!_alive.IsMet(world, entityId))
                return false;

            if (!_direction.IsMet(world, entityId))
                return false;

            return true;
        }
    }
}