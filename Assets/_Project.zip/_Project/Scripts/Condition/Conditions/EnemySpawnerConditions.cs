using _Project.Scripts.Components;

namespace _Project.Scripts.Condition.Conditions
{
    public readonly struct EnemySpawnerConditions : IWorldCondition
    {
        private readonly LimitCondition<EnemySpawnerTag> _limit;

        public EnemySpawnerConditions(LimitCondition<EnemySpawnerTag> limit)
        {
            _limit = limit;
        }

        public bool IsMet(World world, float dt)
        {
            return _limit.IsMet();
        }
    }
}