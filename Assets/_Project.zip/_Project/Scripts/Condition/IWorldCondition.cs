namespace _Project.Scripts.Condition
{
    public interface IWorldCondition
    {
        public bool IsMet(World world, float dt);
    }
}