using _Project.Scripts.Components;
using _Project.Scripts.Entity;

namespace _Project.Scripts.Condition
{
    public readonly struct DirectionCondition
    {
        public bool IsMet(World world, EntityId entityId)
        {
            return world.GetPool<Direction>().Has(entityId);
        }
    }
}