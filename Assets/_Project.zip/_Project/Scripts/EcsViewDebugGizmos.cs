using _Project.Scripts;
using UnityEngine;
using _Project.Scripts.Components;
using EntityId = _Project.Scripts.Entity.EntityId;

public sealed class EcsViewDebugGizmos : MonoBehaviour
{
    public World World;
    public EntityId Entity;

    private void OnDrawGizmos()
    {
        if (World == null)
            return;

        if (!World.GetPool<Position>().Has(Entity))
            return;

        var ecsPos = World.GetPool<Position>().Get(Entity);
        var ecsWorldPos = new Vector3(ecsPos.X, 0f, ecsPos.Z);
        var viewPos = transform.position;

        // ECS — КРАСНЫЙ
        Gizmos.color = Color.red;
        Gizmos.DrawSphere(ecsWorldPos, 0.15f);

        // VIEW — СИНИЙ
        Gizmos.color = Color.blue;
        Gizmos.DrawSphere(viewPos, 0.15f);

        // ЛИНИЯ РАССИНХРОНА
        if (Vector3.Distance(ecsWorldPos, viewPos) > 0.05f)
        {
            Gizmos.color = Color.yellow;
            Gizmos.DrawLine(ecsWorldPos, viewPos);
        }
    }
}