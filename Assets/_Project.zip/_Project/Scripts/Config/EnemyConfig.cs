using UnityEngine;

namespace _Project.Scripts.Configs
{
    [CreateAssetMenu(menuName = "Configs/Enemy Config")]
    public sealed class EnemyConfig : ScriptableObject
    {
        [Header("Health")]
        public float MaxHealth = 100f;

        [Header("Movement")]
        public float MoveSpeed = 3f;
        public float StopDistance = 1.5f;

        [Header("Attack")]
        public float DamagePerSecond = 5f;
        public float AttackRange = 1.5f;

        [Header("Spawn")]
        public float SpawnInterval = 7f;
        public float SpawnOffset = 2f; // 👈 ВАЖНО

        [Header("Collision")]
        public float CollisionRadius = 0.6f;

        [Header("Loot")]
        [Range(0f, 1f)]
        public float CoinDropChance = 0.5f;
        public GameObject Prefab;
    }
}