using UnityEngine;

namespace _Project.Scripts.Configs
{
    [CreateAssetMenu(menuName = "Configs/Coin Config")]
    public sealed class CoinConfig : ScriptableObject
    {
        public float CollisionRadius = 0.5f; //подумать над синхронизацией
        public GameObject Prefab;
    }
}