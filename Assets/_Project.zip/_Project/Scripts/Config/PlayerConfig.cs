using UnityEngine;

namespace _Project.Scripts.Configs
{
    [CreateAssetMenu(menuName = "Configs/Player Config")]
    public sealed class PlayerConfig : ScriptableObject
    {
        [Header("Movement")]
        public float MoveSpeed = 7f;

        [Header("Health")]
        public float MaxHealth = 100f;

        [Header("Shooting")]
        public float ShootInterval = 1f;
        public float ProjectileDamage = 25f;
        public float ProjectileSpeed = 10f;
        public float ProjectileRadius = 0.2f;

        public float CollisionRadius = 0.5f;
        
        public float ProjectileLifetime = 5f;
        public GameObject Prefab;
    }
}