using UnityEngine;

namespace _Project.Scripts.Configs
{
    [CreateAssetMenu(menuName = "Configs/EnemySpawner Config")]
    public sealed class EnemySpawnerConfig : ScriptableObject
    {
        public float SpawnInterval = 7f;
        public float SpawnOffset = 2f;
    }
}