namespace _Project.Scripts.Events
{
    public sealed class SpawnListener<TTag> : IEventListener<SpawnEvent<TTag>>
        where TTag : struct
    {
        public void OnEvent(in SpawnEvent<TTag> evt)
        {
            throw new System.NotImplementedException();
        }
    }
}