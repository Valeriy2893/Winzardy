using _Project.Scripts.Components;

namespace _Project.Scripts.Unity.View
{
    public sealed class ViewCleanupListener : IEventListener<EntityDestroyedEvent>
    {
        private readonly ViewRegistry _views;

        public ViewCleanupListener(ViewRegistry views)
        {
            _views = views;
        }

        public void OnEvent(in EntityDestroyedEvent evt)
        {
            _views.Remove(evt.Entity);
        }
    }
}