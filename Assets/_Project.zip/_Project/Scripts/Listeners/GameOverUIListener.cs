using _Project.Scripts.Components;
using UnityEngine;
using UnityEngine.UI;

namespace _Project.Scripts.Unity.View
{
    public class GameOverUIListener : IEventListener<EntityDestroyedEvent>
    {
        private readonly World _world;
        private readonly GameObject _panel;
        private readonly System.Action _restart;

        public GameOverUIListener(World world, GameObject panel, Button buttonRestart, System.Action restart)
        {
            _world = world;
            _panel = panel;
            _restart = restart;
            _panel.SetActive(false);
            
            buttonRestart.onClick.AddListener(() =>
            {
                Time.timeScale = 1f;
                _restart?.Invoke();
            });
        }

        public void OnEvent(in EntityDestroyedEvent evt)
        {
            var entity = evt.Entity;
            if (!_world.GetPool<PlayerTag>().Has(entity)) return;
            _panel.SetActive(true);
            Time.timeScale = 0f;
        }
    }
}