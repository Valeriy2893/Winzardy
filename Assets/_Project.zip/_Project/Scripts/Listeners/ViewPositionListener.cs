using _Project.Scripts.Events;
using UnityEngine;

namespace _Project.Scripts.Unity.View
{
    public class ViewPositionListener : IEventListener<PositionChangedEvent>
    {
        private readonly ViewRegistry _views;

        public ViewPositionListener(ViewRegistry view)
        {
            _views = view;
        }

        public void OnEvent(in PositionChangedEvent evt)
        {
            if (!_views.Has(evt.Entity))
                return;

            var go = _views.Get(evt.Entity);
           go.transform.position = new Vector3(evt.X, go.transform.position.y, evt.Z);
        }
    }
}