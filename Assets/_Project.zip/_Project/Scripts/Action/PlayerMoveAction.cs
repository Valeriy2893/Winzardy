using _Project.Scripts.Components;
using _Project.Scripts.ECS.Systems;
using _Project.Scripts.Events;
using UnityEngine;
using EntityId = _Project.Scripts.Entity.EntityId;

namespace _Project.Scripts.Action
{
    public readonly struct PlayerMoveAction : IAction
    {
        public void Execute(World world, EntityId entity, float dt)
        {
            ref var pos = ref world.GetPool<Position>().Get(entity);
            ref var vel = ref world.GetPool<Velocity>().Get(entity);
            ref var dir = ref world.GetPool<Direction>().Get(entity);


            var d = new Vector2(dir.X, dir.Z);
            if (d.sqrMagnitude > 1f)
                d.Normalize();

            var oldX = pos.X;
            var oldZ = pos.Z;

            pos.X += d.x * vel.Speed * dt;
            pos.Z += d.y * vel.Speed * dt;
            if (!Mathf.Approximately(pos.X, oldX) ||
                !Mathf.Approximately(pos.Z, oldZ))
            {
                world.EventBus.PositionChanged
                    .Raise(new PositionChangedEvent(entity, pos.X, pos.Z));
            }
        }
    }
}