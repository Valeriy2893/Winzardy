using _Project.Scripts.ECS.Systems;
using UnityEngine;
using EntityId = _Project.Scripts.Entity.EntityId;

namespace _Project.Scripts.Action
{
    public readonly struct DeathAction : IAction
    {
        public void Execute(World world, EntityId entity, float dt)
        {
            world.DestroyEntity(entity);
            
        }
    }
}