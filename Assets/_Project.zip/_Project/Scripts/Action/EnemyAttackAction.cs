using _Project.Scripts.Components;
using _Project.Scripts.ECS.Systems;
using _Project.Scripts.Entity;

namespace _Project.Scripts.Action
{
    public readonly struct EnemyAttackAction : IAction
    {
        private readonly EcsFilter<PlayerTag, Health> _player;

        public EnemyAttackAction(EcsFilter<PlayerTag, Health> player)
        {
            _player = player;
        }

        public void Execute(World world, EntityId enemy, float dt)
        {
            if (_player.Entities.Count == 0)
                return;

            var player = _player.Entities[0];

            ref var health = ref world.GetPool<Health>().Get(player);
            ref var damage = ref world.GetPool<DamageOverTime>().Get(enemy);

            health.Current -= damage.DamagePerSecond * dt;
        }
    }
}