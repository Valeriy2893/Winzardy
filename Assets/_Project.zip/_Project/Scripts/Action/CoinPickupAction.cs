using _Project.Scripts.Components;
using _Project.Scripts.ECS.Systems;
using _Project.Scripts.Entity;

namespace _Project.Scripts.Action
{
    public readonly struct CoinPickupAction : IAction
    {
        private readonly EcsFilter<PlayerTag, Resource> _players;

        public CoinPickupAction(EcsFilter<PlayerTag, Resource> players)
        {
            _players = players;
        }

        public void Execute(World world, EntityId coin, float dt)
        {
            if (_players.Entities.Count == 0)
                return;

            var player = _players.Entities[0];

            ref var resource = ref world.GetPool<Resource>().Get(player);
            resource.Value += 1;

            world.DestroyEntity(coin);
        }
    }
}