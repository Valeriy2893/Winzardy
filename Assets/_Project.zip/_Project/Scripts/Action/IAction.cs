using _Project.Scripts.Entity;

namespace _Project.Scripts.ECS.Systems
{
    public interface IAction
    {
        public void Execute(World world, EntityId entity, float dt);
    }
}